# Flight-Booking-System
Systems Analysis and Design Project (CS4125)

## Brief Ideas

These ideas are subject to change. Please feel free to change the markdown as you wish.  

### Users

***

#### Customers

- Book flights
- View booked flights
- Cancel a flight

#### Admin

- Add flight paths
- Add flight times and dates
- Add plane types
- View customers for a certain flight(s)

### Policies

***

- age range different prices
- at least 1 adult accompanying children under 16
- add-ons with check in bags/prams/guitars etc.
- picking seats
- lounges
- ticket classes - economy, business, first class
- cancellation policies - 48 hours before is refundable
- priority boarding
- travel insurance
