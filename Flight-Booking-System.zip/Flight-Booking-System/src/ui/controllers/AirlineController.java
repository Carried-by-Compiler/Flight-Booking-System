
package ui.controllers;

import business_layer.AirlineManager;


/**
 *
 * @author Sophia
 */

/*
    it only get the id - manager 
    check if the airline exisit and validate input 
    handle button presses for airline user
    private class for the button listen and use a switch case and get it to handle ariline stuff 
    all processing should be in these classes 
    same login screen but enter the airline login? so validatwe the input to see what class - extra querying 
    input for customer and airline is different?
    Login for ariline is not on the same page in IRL 
    encapsulation - so airline and customer will be seperate 
*/
public class AirlineController {
    
}
