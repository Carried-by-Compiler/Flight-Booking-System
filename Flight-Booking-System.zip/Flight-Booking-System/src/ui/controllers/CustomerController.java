
package ui.controllers;
import business_layer.CustomerManager;

/**
 *
 * @author Sophia
 */

/*
    Initialise login and customer manager and register
    in main but takes in those;
    "error handling"
    checks for if login is correct and register is correct (exisit or not)
    take it out of customer;
    Once the gui gets the info? action listener placed here - wil parser it? and then it will query the manager 
    and the manager will query the database;
    yeah ok
    Has reference to airline manager class? 
    Tab to switch to airline login GUI?
    customer, airline and flight managers in here?
    if airline button is pressed... airline Controller
    Registration is not an option for the airline - We'll assume all our airlines are registered. 
    Managers don't assume there's a GUI - takes in values of the manager 
*/
public class CustomerController {
    
}
